﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets; //using TCP sockets to communicate
using System.Threading;

//Author Herr Dhali Amin Al

namespace Comp1564client
{
    public partial class Form1 : Form
    {
        private static bool questioning = false;  //boolean for asking
        private static bool listening = true;  //boolean for listening
        private static Socket socket;
        private static bool spielestart = false;   //gamestart=false
        private object counting;

        public Form1()
        {
            InitializeComponent();
            buttonDisconnect.Enabled = false;
            textBoxIpAddress.Text = "127.0.0.1";   //set as local ip address
            textBoxPort.Text = "8000";   // Port can be from 8000-8009
            string localIpAddress = GetLocalIPAddress_AsString(); // Get local IP address as a default value
            textBoxIpAddress.Text = localIpAddress;             // Place local IP address in IP address field
        }
    

      private void buttonConnectServer_Click(object sender, EventArgs e)
        {
            if(textBoxName.Text == "")
            {
                writeRichTextBox("User name cannot be empty.");  //server to clients, Must have an username
                return;
            }
            try
            {
                string ipAdd = textBoxIpAddress.Text;
                int port = Int32.Parse(textBoxPort.Text);    //11000
                // Establish the remote endpoint for the socket.  
                // This example uses port (8000-8009) on the local computer.  
                IPAddress ipAddress = IPAddress.Parse(ipAdd);   //textbox=server Ip address
                IPEndPoint remoteEndpoint = new IPEndPoint(ipAddress, port);  //remoteEndpoint for IP

                // Create a TCP/IP  socket.  
                socket = new Socket(ipAddress.AddressFamily,
                    SocketType.Stream, ProtocolType.Tcp);  //Tcp protocol for socket connections
                socket.Connect(ipAdd, port);
                
                this.Text = "Client Side Connector - Client Name: " + textBoxName.Text;    //Client name = textbox name
                buttonConnectingServer.BackColor = Color.DarkBlue;  //Chnaging color of the button while being connceted
                buttonConnectingServer.Text = "Connected";
                buttonDisconnect.Enabled = true;
                listening = true;


                // Send the data through the socket.  
                sendArbitraryLengthMessage(textBoxName.Text); // sending unencrypted text messages thorugh tcp socket
                buttonConnectingServer.Enabled = false;
                Thread receiveMessageThread = new Thread(receiveMessage);  //recieving message thread
                receiveMessageThread.Start();
            }
            catch (Exception ex)
            {
                Invoke(new Action(() => { writeRichTextBox(ex.ToString()); }));
                buttonConnectingServer.BackColor = Color.Red;
            }
        }

        private void buttonClearStatus_Click(object sender, EventArgs e)
        {
            richTextBoxStatus.Text = "";   //Clearing all datas from richtextboc
        }

        private void receiveMessage()
        {
            while (listening)
            {
                try
                {
                    string message = ReceiveArbitraryLengthMessage();   //recieving unencryped message
                    Invoke(new Action(() => { writeRichTextBox("Server : \n" + message); }));
                    if (message.Contains("Game started."))
                    {
                        spielestart = true;
                        Invoke(new Action(() => { buttonSendquestionandanswer.Enabled = true; }));
                   
                    }
                    else if (message.Contains("You are asking this turn."))
                    {
                        Invoke(new Action(() => {
                            buttonSendquestionandanswer.Enabled = true;
                            buttonSendquestionandanswer.Text = "Send question";  
                            richTextBoxQuestion.Enabled = true;
                            richTextBoxAnswer.Enabled = true;
                            richTextBoxMessage.Enabled = true;
                            questioning = true;
                        }));
                      
                    }
                    else if (message.Contains("You are answering this turn."))
                    {
                        Invoke(new Action(() => {
                            buttonSendquestionandanswer.Enabled = true;
                            buttonSendquestionandanswer.Text = "Send answer";
                            richTextBoxQuestion.Enabled = false; //blocking question richtextbox field while answering
                            richTextBoxAnswer.Enabled = true; //rich textbox answer will open while answering
                            richTextBoxMessage.Enabled = true;
                            questioning = false;
                        }));

                    }
                    else if (message.Contains("Your name already exists. Pick another name."))
                    {
                        Invoke(new Action(() => {
                            buttonConnectingServer.Enabled = true;
                            buttonConnectingServer.BackColor = Color.Red;    //for changing backcolor
                            buttonConnectingServer.Text = "Connect to Server";
                            buttonDisconnect.Enabled = false;
                        }));

                    }
                    else if (message.Contains("Game ends.") || message.Contains("SERVER SHUTDOWN."))
                    {
                        Invoke(new Action(() => {    //calling a new action
                            listening = false;
                            socket.Close();
                            buttonDisconnect.Enabled = false;
                            Invoke(new Action(() => {         //implement it by taking help from Richard's source
                                buttonConnectingServer.BackColor = default(Color);
                                buttonConnectingServer.Enabled = true;
                                buttonConnectingServer.Text = "Connect to Server";
                                buttonSendquestionandanswer.Enabled = false;
                                richTextBoxQuestion.Text = "";
                                richTextBoxAnswer.Text = "";
                                richTextBoxQuestion.Enabled = false;
                                richTextBoxAnswer.Enabled = false;
                                richTextBoxMessage.Enabled = true;  //Message isn't working
                                writeRichTextBox("You disconnected.");
                            }));
                        }));

                    }

                }
                catch (Exception ex)
                {
                    if (listening)
                    {
                        Invoke(new Action(() => { writeRichTextBox("Error in receiving  thread : \n" + ex.ToString()); }));
                    }
                    listening = false;
                }
            }
        }

        private void buttonSendAction_Click(object sender, EventArgs e)
        {
            if(richTextBoxAnswer.Text == "")
            {
                writeRichTextBox("Your answer cannot be empty.");   //when answr is null
                return;
            }
            if (questioning && richTextBoxQuestion.Text == "")
            {
                writeRichTextBox("Your question cannot be empty.");   // when question is null
                return;
            }
            buttonSendquestionandanswer.Enabled = false;

            if (questioning)
            {
                sendArbitraryLengthMessage(richTextBoxQuestion.Text + ":" + richTextBoxAnswer.Text   + ":"  +richTextBoxMessage.Text);
            }
            else
            {
                sendArbitraryLengthMessage(richTextBoxAnswer.Text    + ":"   + richTextBoxMessage.Text);     //message part isn't working yet
            }
            
        }


       

        private void sendArbitraryLengthMessage(string message)
        {
            int messageLength = message.Length;
            byte[] intBytes = BitConverter.GetBytes(messageLength);
            if (BitConverter.IsLittleEndian)   //most significant byte is on the right end
                Array.Reverse(intBytes);   //...reversing integer btes
            byte[] result = intBytes;
            
            // First send of the length of the message in 4 bytes
            int bytesSent = socket.Send(result);
            byte[] msg = Encoding.ASCII.GetBytes(message);
            //then send the message itself
            socket.Send(msg);
        }


        

        private string ReceiveArbitraryLengthMessage() // tO REcieve all unencrypted type message
        {
            //first receive the length of the incoming message in 4 bytes(integer)
            byte[] messageLengthByte = new byte[4];
            socket.Receive(messageLengthByte);
            if (BitConverter.IsLittleEndian)    //most significant bit is on the right of a word/number
                Array.Reverse(messageLengthByte);
            int messageLengthInt = BitConverter.ToInt32(messageLengthByte, 0);


            //then receive the message string
            byte[] messageByte = new byte[messageLengthInt];
            int k = socket.Receive(messageByte);   //socket recieving bytes 
            string message = Encoding.ASCII.GetString(messageByte, 0, k);
            return message;
        }



        public string GetLocalIPAddress_AsString()
        {
            string szHost = Dns.GetHostName();   //Domain Name system
            string szLocalIPaddress = "127.0.0.1";  // Default is local loopback address
            IPHostEntry IPHost = Dns.GetHostEntry(Dns.GetHostName());    //Host IP entry
            foreach (IPAddress IP in IPHost.AddressList)
            {
                if (IP.AddressFamily == AddressFamily.InterNetwork) // Match only the IPv4 address
                {
                    szLocalIPaddress = IP.ToString();   //Converting IP Adress to string
                    break;
                }
            }
            return szLocalIPaddress;
        }



        public void writeRichTextBox(string message)
        {
            richTextBoxStatus.Text += message + "\n";   //adding new messages after the previous message to rich text box

            richTextBoxStatus.SelectionStart = richTextBoxStatus.Text.Length;
            // scroll it automatically
            richTextBoxStatus.ScrollToCaret();
        }

        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            try
            {
                listening = false;
                sendArbitraryLengthMessage("DISCONNECT");
                socket.Close();
                buttonDisconnect.Enabled = false;
                Invoke(new Action(() => {
                    buttonConnectingServer.BackColor = default(Color);
                    buttonConnectingServer.Enabled = true;
                    buttonConnectingServer.Text = "Connect to Server";
                    buttonSendquestionandanswer.Enabled = false;
                    richTextBoxQuestion.Text = "";
                    richTextBoxAnswer.Text = "";
                    richTextBoxMessage.Text = "";
                    richTextBoxQuestion.Enabled = false;
                    richTextBoxAnswer.Enabled = false;
                    richTextBoxMessage.Enabled = false;
                    writeRichTextBox("You disconnected.");
                    if (spielestart)
                    {
                        buttonConnectingServer.Enabled = false;
                    }
                }));
            }
            catch(Exception ex)
            {
                Invoke(new Action(() => {writeRichTextBox(ex.ToString()); }));
            }
            
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try
            {
                listening = false;
                sendArbitraryLengthMessage("DISCONNECT");
                socket.Close();
                buttonDisconnect.Enabled = false;
                Invoke(new Action(() =>
                {
                    buttonConnectingServer.BackColor = default(Color);
                    buttonConnectingServer.Enabled = true;
                    buttonConnectingServer.Text = "Connect to Server";
                    writeRichTextBox("You disconnected."); //From server to clients while form is closing
                }));
            }
            catch (Exception ex)
            {
                Invoke(new Action(() => { writeRichTextBox(ex.ToString()); }));
            }
            
        }
    }
}
