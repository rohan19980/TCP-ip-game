﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Comp1564client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comp1564client.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void GetLocalIPAddress_AsStringTest()
        {
            Assert.Fail();
        }
    }
}