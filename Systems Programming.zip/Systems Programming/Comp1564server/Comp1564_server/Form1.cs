﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Comp1564server
{
    public partial class Form1 : Form
    {
        private static IPEndPoint localExtPoint ;
        private static Socket serverlisten ;  
        private static List<Client> clients = new List<Client>(); //Listing clients
        private static List<bool> sentmessage = new List<bool>();
        private static List<string> aandq = new List<string>();  //Answers and Questions
        private static List<string> message = new List<string>();
        private static List<int> pointList = new List<int>();
        private readonly object clientsLock = new object();

        private static int turnIndex = 0; //assigning turn index = 0
        private static bool gameNotStarted = true;
        private static bool gameFinished = false;
        private static int currentRound = 0;
        private static int countinground;   //incrementing round

        private static Thread listenThread;

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonStartServer_Click(object sender, EventArgs e)
        {
            try
            {
                int port = Int32.Parse(textBoxPort.Text);  //32 byte int
                startServer(port);    //binding
                listenThread = new Thread(startListening);  //Listening for clients
                listenThread.Start();
                buttonServerReady.Enabled = false; 
                textBoxPort.Enabled = false;
            }
            catch
            {
                Invoke(new Action(() => { writeToRichTextBox("Please enter an integer port number"); }));  //port ot listen for clients

            }
            
            
        }
public void startServer(int port){
            try {
                //ipHostInfo = Dns.Resolve(Dns.GetHostName());  
                //ipAddress = ipHostInfo.AddressList[0];  
                serverlisten = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);//using socket for tcp protocol
                
                localExtPoint = new IPEndPoint(IPAddress.Any, port);  //IP of the server machien= local Ext point
                Invoke(new Action(() => { writeToRichTextBox("Server opened."); }));    //Starting server fter assigining a port
            }
            catch(Exception ex){
                Invoke(new Action(() => { writeToRichTextBox(ex.ToString()); }));   
            }
        }
         public void startListening(){
            
            try
            {
                serverlisten.Bind(localExtPoint);
                serverlisten.Listen(10);
                Invoke(new Action(() => { writeToRichTextBox("Started listening for connecting clients."); }));  //Looking for 
                                                                                         //connected clients, maximum= 2 
                
                //accept clients until there 2 clients connected
                while (gameNotStarted)
                {
                    Console.Write(gameNotStarted);
                    Socket newClientSocket = serverlisten.Accept();   //after binding, server listens and accept new client
                    Client newClient = new Client("", newClientSocket); 
                    newClient.username = newClient.receiveMessage();
                    Thread newCLientListenThread = new Thread(() => clientListenThread(newClient)); //thread for listening new client
                    newCLientListenThread.Start();


                    bool acceptable = true;
                    lock (clientsLock)
                    {
                        foreach (Client cl in clients)
                        {
                            if (newClient.username == cl.username)
                            {
                                acceptable = false;
                                Invoke(new Action(() => { writeToRichTextBox("New client with name : " + newClient.username + " can't join because her name already exists."); }));
                                newClient.sendMessage("Your name already exists. Pick another name."); //username assigns to the richtetbox
                                                                                                   //if new username= any other username, clients can't be connected
                            }
                        }
                    }
                    

                    if (acceptable && gameNotStarted)
                    {
                        lock (clientsLock)
                        {
                            clients.Add(newClient);
                        }
                        newClient.sendMessage("You connected to server.");
                        sendMessageToAllClients("New client with name : " + newClient.username + " connected.");     //Sendto all clients in rich textbox
                        
                    }                    
                }
            }
            catch(Exception e)
            {
                Invoke(new Action(() => { writeToRichTextBox("Error occured while listening to connections. Error message:\n" + e.ToString()); }));
            }
            Console.Write("Stopped listening for client connections.\n");
            
        }


        public void RemoveClient(Client client)
        {
            int indexOfClient = clients.IndexOf(client);
            clients.Remove(client);
            Console.Write("Index of client : " + indexOfClient.ToString() + " client count : " + clients.Count.ToString() + "\n");
            if (turnIndex > indexOfClient)
            {
                turnIndex = (turnIndex - 1) % clients.Count;
            }
            //means that last client in the client list disconnected
            else if (indexOfClient == clients.Count)
            {
                turnIndex = 0;
            }
            if (!gameNotStarted)
            {
                sentmessage.RemoveAt(indexOfClient);
                aandq.RemoveAt(indexOfClient);    //ans and questions on client index
                pointList.RemoveAt(indexOfClient);
            }

        }


        public void clientListenThread(Client client)  //threading for listening to clients    //took help from ricards's code
        {
            while (!gameFinished || gameNotStarted)
            {
                try
                {
                    string message = client.receiveMessage();

                    if (message == "DISCONNECT")
                    {
                        bool isDisconnectorAsker = clients.IndexOf(client) == turnIndex;
                        lock (clientsLock)
                        {
                            //we have to remove the client information from multiple lists thats why we call a free function here
                            RemoveClient(client);
                        }
                        sendMessageToAllClients(client.username + " " + "has disconnected.");  //sending message to all clients

                        if (!gameNotStarted)
                        {
                            lock (clientsLock)
                            {
                                if (clients.Count < 2)
                                {
                                    gameFinished = true;
                                    gameNotStarted = false;
                                    clients[0].sendMessage("You win.");
                                    clients[0].sendMessage("Game ends.");
                                }
                                //check if the disconnector was asking question
                                else if(isDisconnectorAsker)   //rotating turns for clients
                                {
                                    sendMessageToAllClients("New asker : " + clients[turnIndex].username);
                                    clients[turnIndex].sendMessage("You are asking this turn.");   
                                    sendMessageToAllClientsExceptOne("You are answering this turn.", clients[turnIndex]);
                                }
                            }
                        }
                        
                        return;
                    }
                    //then it means that this is a question or an answer
                    else if(!gameFinished)
                    {
                        int indexOfClient = clients.IndexOf(client);
                        if (indexOfClient == turnIndex)
                        {
                            string questionAnswer = message;
                            string question = questionAnswer.Substring(0, questionAnswer.IndexOf(':'));
                            string answer = questionAnswer.Substring(questionAnswer.IndexOf(':') + 1);
                            sendMessageToAllClientsExceptOne("Question: "+question, client); //for sending question
                        }
                        sentmessage[indexOfClient] = true;
                        aandq[indexOfClient] = message;
                        bool allHasSent = true;
                        for (int i = 0; i <sentmessage.Count; i++)
                        {
                            if (!sentmessage[i])
                            {
                                allHasSent = false;
                                break;
                            }
                        }
                        if (allHasSent)
                        {
                            Thread handleAnswerThread = new Thread(handleAnswers);
                            handleAnswerThread.Start();
                        }
                    }
                }
               
                catch(Exception ex)
                {
                    writeToRichTextBox(ex.ToString());
                }
            }
            Console.Write("Stopped listening for client " + client.username + "\n");
        }
      
        public void sendMessageToAllClients(string message)
        {
            writeToRichTextBox(message);
            lock (clientsLock)
                // send to all clients
            {
                foreach (Client client in clients)
                {
                    client.sendMessage(message);
                }
            }
            
        }
        public void sendMessageToAllClientsExceptOne(string message, Client clientX)
        {
            lock(clientsLock)
            {    //only send message to a single client
                foreach (Client client in clients)
                {
                    if (clientX != client)
                    {
                        client.sendMessage(message);
                    }

                }
            }
            
        }

        //Gaming functionality
        private void handleAnswers() {

            string questionAnswer = aandq[turnIndex];
            string question = questionAnswer.Substring(0, questionAnswer.IndexOf(':'));
            string answer = questionAnswer.Substring(questionAnswer.IndexOf(':') + 1); 
            for(int i=0; i < clients.Count; i++)
            {
                if (i != turnIndex)
                {
                    if(aandq[i] != answer)
                    {
                        sendMessageToAllClients(clients[i].username + " Answered Wrongly");
                    }
                    else
                    {
                        pointList[i] += 1;
                        sendMessageToAllClients(clients[i].username + " Answered Correctly");
                    }
                }
            }
            for (int i = 0; i < clients.Count; i++)
            {
                sentmessage[i] = false;
            }
            string scores = "";
            turnIndex = (turnIndex + 1) % clients.Count;
            for (int i = 0; i < pointList.Count; i++)
            {
                scores += clients[i].username + " : " + pointList[i].ToString() + "\n";

            }
            sendMessageToAllClientsExceptOne("You are answering this turn.", clients[turnIndex]);
            clients[turnIndex].sendMessage("You are asking this turn.");
            
            sendMessageToAllClients(scores);
            if(currentRound + 2 <= countinground)
            {
                sendMessageToAllClients("Round : " + (currentRound + 2).ToString());
                writeToRichTextBox(clients[turnIndex].username + " is asking this turn.");
            }
            
            if (++currentRound == countinground)
            {
                gameFinished = true;
                gameNotStarted = false;
                int maxScore = -1;
                for (int i = 0; i < pointList.Count; i++)
                {
                    if(pointList[i] > maxScore)
                    {
                        maxScore = pointList[i];   //show max score on rtbox
                    }
                }
                List<int> winnerIndexes = new List<int>();
                for (int i = 0; i < pointList.Count; i++)
                {
                    if (pointList[i] == maxScore)
                    {
                        winnerIndexes.Add(i); 
                    }
                }
                string winnerMessage = "";
                foreach(int index in winnerIndexes)
                {
                    winnerMessage += clients[index].username + " wins with a score of : " + pointList[index] + "\n";
                } //show winner
                sendMessageToAllClients(winnerMessage);
                sendMessageToAllClients("Game ends.");
                return;
            }
            
        }

        
        private void buttonClearStatusBox_Click(object sender, EventArgs e)
        {
            richTextBoxInformation.Text = "";   //clearing rich textbox
        }
        public void writeToRichTextBox(string message)
        {

            Invoke(new Action(() =>
            {
                richTextBoxInformation.Text += message + "\n";
                richTextBoxInformation.SelectionStart = richTextBoxInformation.Text.Length;
                // scroll it automatically
                richTextBoxInformation.ScrollToCaret();
            }));
        }

        private void buttonStartGame_Click(object sender, EventArgs e)
        {
            int clientCount;
            lock (clientsLock)
            {
                clientCount = clients.Count;
            }
            //means that game should start
            if (clientCount > 1)
            {
                
                try
                {
                    string numRounds = textBoxNumRounds.Text;


                    if (numRounds == "")
                    {
                        writeToRichTextBox("Please enter a valid number for number of rounds.");
                        return;
                    }
                    countinground = Int32.Parse(numRounds); //parsing number of rounds
                    gameNotStarted = false;
                    clients.Sort((x, y) => x.username.CompareTo(y.username)); //sorting clients
                    sendMessageToAllClients("Game started.");
                    clients[turnIndex].sendMessage("You are asking this turn."); //to clients richtextbox
                    writeToRichTextBox("Client : " + clients[0].username + " is asking this turn.");
                    sendMessageToAllClients("Round : " + (currentRound + 1).ToString()); 
                    sendMessageToAllClientsExceptOne("You are answering this turn.", clients[turnIndex]);
                    for(int i = 0; i < clients.Count; i++)
                    {
                        aandq.Add("");        //answer and questions = false, points= 0
                        sentmessage.Add(false);
                        pointList.Add(0);
                    }
                }
                catch (FormatException ex)
                {
                    writeToRichTextBox("Please enter a valid number for number of rounds.");
                }
                catch(Exception ex)
                {
                    writeToRichTextBox(ex.ToString());
                }


            }
            else
            {
                writeToRichTextBox("There are not enough players to start the game.");
            }

        }
 protected override void OnFormClosing(FormClosingEventArgs e)
        {
            try
            {
                sendMessageToAllClients("SERVER SHUTDOWN.");
                foreach(Client client in clients)
                {
                    client.mysocket.Close();
                }
            }
            catch (Exception ex)
            {
                Invoke(new Action(() => { writeToRichTextBox(ex.ToString()); }));
            }

        }
    }
}
