﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Comp1564server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comp1564server.Tests
{
    [TestClass()]
    public class ClientTests
    {
        [TestMethod()]
        public void ClientTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void socketisActiveTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void sendMessageTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void receiveMessageTest()
        {
            Assert.Fail();
        }
    }
}