﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Comp1564server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comp1564server.Tests
{
    [TestClass()]
    public class Form1Tests
    {
        [TestMethod()]
        public void Form1Test()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void startServerTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void startListeningTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void RemoveClientTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void clientListenThreadTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void sendMessageToAllClientsTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void sendMessageToAllClientsExceptOneTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void writeToRichTextBoxTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void startListeningTest1()
        {
            Assert.Fail();
        }
    }
}